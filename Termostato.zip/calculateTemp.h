#ifndef CALCULATETEMP_H
#define CALCULATETEMP_H



//Funciones

int calcular(char hexa[5],char temperatura[5],int largo);
float calcularVelocidad(int frecuencia);

#endif
