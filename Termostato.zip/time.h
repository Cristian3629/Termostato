#ifndef TIME_H
#define TIME_H



//Funciones
int wait(int (*lista)[6]);
void getHrMinSec(char* hora,int (*lista)[6]);
void printTime(int (*list)[6]);
int incrementMinute(int *minutes);

#endif
