#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <string.h> //srtlen()


#include "aceptador.h"
#include "conectador.h"
#include "date.h"
#include "lista.h"

int server(int argc, char *argv[]);


#endif
